<?php require ('utilities/header.php') ?>


<div class="dash_right_body">
	<div class="container-fluid">
		<div class="row round shadow bg-white">
			<div class="col col-12 py-4">
				<div class="notice_img">
					<img src="img/notice.png">
				</div>
			</div>


		</div>
	</div>
</div>


<?php require ('utilities/footer.php') ?>